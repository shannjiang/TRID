TRID <- function(datExpr, datExpr_annotation, connectivity_method = NULL)
{
if (is.null(connectivity_method)) connectivity_method = "pearson"
datExpr_splitted = lapply(split(datExpr[,1:length(colnames(datExpr))],datExpr_annotation$Disease_status),matrix,ncol=length(colnames(datExpr)))
control_datExpr = datExpr_splitted$'0'
control_datExpr_cor = rcorr(control_datExpr, type=connectivity_method)
control_datExpr_cor_matrix = control_datExpr_cor[1]$r
control_whole_connectivity = vector(mode="numeric",length=length(colnames(datExpr)))
for (i in 1:length(colnames(datExpr))) {
control_whole_connectivity[i] = sum(abs(control_datExpr_cor_matrix[,i]))
}
control_whole_connectivity = as.matrix(control_whole_connectivity)
row.names(control_whole_connectivity) = colnames(datExpr)
colnames(control_whole_connectivity) = c("kTotal")
control_whole_connectivity = data.frame(control_whole_connectivity)
case_datExpr = datExpr_splitted$'1'
case_datExpr_cor = rcorr(case_datExpr, type=connectivity_method)
case_datExpr_cor_matrix = case_datExpr_cor[1]$r
case_whole_connectivity = vector(mode="numeric",length=length(colnames(datExpr)))
for (i in 1:length(colnames(datExpr))) {
case_whole_connectivity[i] = sum(abs(case_datExpr_cor_matrix[,i]))
}
case_whole_connectivity = as.matrix(case_whole_connectivity)
row.names(case_whole_connectivity) = colnames(datExpr)
colnames(case_whole_connectivity) = c("kTotal")
case_whole_connectivity = data.frame(case_whole_connectivity)
control_whole_connect_mean = mean(control_whole_connectivity$kTotal)
control_whole_connect_sd = sd(control_whole_connectivity$kTotal)
case_whole_connect_mean = mean(case_whole_connectivity$kTotal)
case_whole_connect_sd = sd(case_whole_connectivity$kTotal)
###control_whole_connect standardization
control_whole_connect_standardized = vector(mode="numeric",length=length(control_whole_connectivity$kTotal))
for (i in 1:length(control_whole_connectivity$kTotal)) {
control_whole_connect_standardized[i] = (control_whole_connectivity$kTotal[i] - control_whole_connect_mean)/control_whole_connect_sd
}
###case_whole_connect standardization
case_whole_connect_standardized = vector(mode="numeric",length=length(case_whole_connectivity$kTotal))
for (i in 1:length(case_whole_connectivity$kTotal)) {
case_whole_connect_standardized[i] = (case_whole_connectivity$kTotal[i] - case_whole_connect_mean)/case_whole_connect_sd
}
###connect_difference standardization
connect_difference = vector(mode="numeric",length=length(control_whole_connectivity$kTotal))
for (i in 1:length(control_whole_connectivity$kTotal)) {
connect_difference[i] = case_whole_connect_standardized[i] - control_whole_connect_standardized[i]
}
connect_difference = abs(connect_difference)
connect_difference_mean = mean(connect_difference)
connect_difference_sd = sd(connect_difference)
connect_difference_standardized = vector(mode="numeric",length=length(connect_difference))
for (i in 1:length(connect_difference)) {
connect_difference_standardized[i] = (connect_difference[i] - connect_difference_mean)/connect_difference_sd
connect_difference_standardized[i] = connect_difference_standardized[i] + 2
}
###welcht_statistics calculation
t = vector(mode="numeric",length=length(colnames(datExpr)))
p = vector(mode="numeric",length=length(colnames(datExpr)))
for (i in 1:length(colnames(datExpr))) {
A = t.test(datExpr[,i] ~ datExpr_annotation$Disease_status)
t[i] = A$statistic
p[i] = A$p.value
}
welcht_statistics_matrix = t(rbind(t,p))
row.names(welcht_statistics_matrix) = colnames(datExpr)
welcht_statistics = data.frame(welcht_statistics_matrix)
###welcht_statistics standardization
welcht_statistics$t = abs(welcht_statistics$t)
welcht_mean = mean(welcht_statistics$t)
welcht_sd = sd(welcht_statistics$t)
welcht_standardized = vector(mode="numeric",length=length(welcht_statistics$t))
for (i in 1:length(welcht_statistics$t)) {
welcht_standardized[i] = (welcht_statistics$t[i] - welcht_mean)/welcht_sd
welcht_standardized[i] = welcht_standardized[i] + 2
}
###raw_DiCODE calculation
raw_DiCODE = vector(mode="numeric",length=length(welcht_standardized))
for (i in 1:length(welcht_standardized)) {
raw_DiCODE[i] = welcht_standardized[i] + connect_difference_standardized[i]
}
connect_difference_standardized_max = max(connect_difference_standardized)
connect_difference_standardized_min = min(connect_difference_standardized)
connect_difference_standardized_scaled = vector(mode="numeric",length=length(connect_difference_standardized))
for (i in 1:length(connect_difference_standardized)) {
connect_difference_standardized_scaled[i] = (connect_difference_standardized[i] - connect_difference_standardized_min)/(connect_difference_standardized_max - connect_difference_standardized_min)
}
welcht_standardized_max = max(welcht_standardized)
welcht_standardized_min = min(welcht_standardized)
welcht_standardized_scaled = vector(mode="numeric",length=length(welcht_standardized))
for (i in 1:length(welcht_standardized)) {
welcht_standardized_scaled[i] = (welcht_standardized[i] - welcht_standardized_min)/(welcht_standardized_max - welcht_standardized_min)
}
raw_DiCODE_max = max(raw_DiCODE)
raw_DiCODE_min = min(raw_DiCODE)
raw_DiCODE_scaled = vector(mode="numeric",length=length(raw_DiCODE))
for (i in 1:length(raw_DiCODE)) {
raw_DiCODE_scaled[i] = (raw_DiCODE[i] - raw_DiCODE_min)/(raw_DiCODE_max - raw_DiCODE_min)
}
final_result = t(rbind(raw_DiCODE_scaled,welcht_standardized_scaled,connect_difference_standardized_scaled))
row.names(final_result) = colnames(datExpr)
colnames(final_result) = c("DiCODE_weight", "Differential_expression_weight", "Differential_connectivity_weight")
final_result
}
